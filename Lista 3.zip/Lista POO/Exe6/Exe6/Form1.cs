﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            Calculo calculo = new Calculo();
            calculo.setCotacao(Convert.ToDouble(txt_cotacao.Text));
            calculo.setDolar(Convert.ToDouble(txt_dolar.Text));
            calculo.calcularDolar();
            lbl_resultado.Text = calculo.getDolar()+" dolares equivale a " +calculo.getResultado() + " reais";
        }
    }
}
