﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe6
{
    internal class Calculo
    {
        private double cotacao;
        private double dolar;
        private double resultado;

        public Calculo(double cotacao, double dolar, double resultado)        {
            this.cotacao = cotacao;
            this.dolar = dolar;
            this.resultado = resultado;
        }

        public Calculo()
        {
            this.cotacao = 0;
            this.dolar = 0;
            this.resultado = 0;
        }

        public void setCotacao(double cotacao)
        {
            this.cotacao = cotacao;
        }

        public void setDolar(double dolar)
        {
            this.dolar = dolar;
        }

        public double getCotacao(){
            return this.cotacao;
        }

        public double getDolar(){
            return this.dolar;
        }

        public double getResultado()
        {
            return this.resultado;
        }

        public void calcularDolar()
        {
            this.resultado = this.cotacao * this.dolar;
        }
    }
}
