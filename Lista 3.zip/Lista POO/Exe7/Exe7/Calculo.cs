﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe7
{
    internal class Calculo
    {
        private int valor1;
        private int valor2;
        private int maior;

        public Calculo(int valor1, int valor2, int maior)
        {
            this.valor1 = valor1;
            this.valor2 = valor2;
            this.maior = maior;
        }

        public Calculo()
        {
            this.valor1 = 0;
            this.valor2 = 0;
            this.maior = 0;
        }

        public void setValor1(int valor1)
        {
            this.valor1 = valor1;
        }

        public void setValor2(int valor2)
        {
            this.valor2 = valor2;
        }

        public int getMaior()
        {
            return this.maior;
        }
        public void verificar()
        {
            if (this.valor1 > this.valor2)
            {
                this.maior = this.valor1;
            }
            else
            {
                this.maior = this.valor2;
            }
        }
    }
}
