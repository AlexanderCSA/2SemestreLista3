﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            Calculo calculo = new Calculo();
            calculo.setValor1(int.Parse(txt_valor1.Text));
            calculo.setValor2(int.Parse(txt_valor2.Text));
            calculo.verificar();
            lbl_resultado.Text = "O valor maior é: " + calculo.getMaior().ToString();
        }
    }
}
