﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace Exe11
{
    internal class Calculo
    {
        private int ladoa;
        private int ladob;
        private int ladoc;
        private string resultado;

        public Calculo (int ladoa, int ladob, int ladoc, string resultado)
        {
            this.ladoa = ladoa;
            this.ladob = ladob;
            this.ladoc = ladoc;
            this.resultado = resultado;
        }

        public Calculo()
        {
            this.ladoa = 0;
            this.ladob = 0;
            this.ladoc = 0;
            this.resultado = "";
        }

        public void setLadoa(int ladoa)
        {
            this.ladoa = ladoa;
        }

        public void setLadob(int ladob)
        {
            this.ladob = ladob;
        }

        public void setLadoc(int ladoc)
        {
            this.ladoc = ladoc;
        }

        public int getLadoa()
        {
            return this.ladoa;
        }

        public int getLadob()
        {
            return this.ladob;
        }

        public int getLadoc()
        {
            return this.ladoc;
        }

        public string getClassficacao()
        {
            return this.resultado;
        }

        public void calcular()
        {
            if ((this.ladoa + this.ladob) > this.ladoc || (this.ladoa + this.ladoc) > this.ladob || (this.ladob + this.ladoc) > this.ladoa)
            {
                if (this.ladoa == this.ladob && this.ladob == this.ladoc)
                {
                    this.resultado = "Triangulo equilatero";
                }
                else if(this.ladoa == this.ladob || this.ladob == this.ladoc || this.ladoa == this.ladoc)
                {
                    this.resultado = "Triangulo isosceles";
                }
                else
                {
                    this.resultado = "Triangulo escaleno";
                }
            }
            else
            {
                this.resultado = "Não forma uma triangulo!";
            }
        }
    }
}
