﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe5
{
    internal class Calculo
    {
        private double milhas;
        private double resultado;

        public Calculo(double milhas)
        {
            this.milhas = milhas;
        }

        public Calculo()
        {
            this.milhas = 0;
        }

        public void setMilhas(double milhas)
        {
            this.milhas = milhas;
        }
        public double getMilhas()
        {
            return this.milhas;
        }

        public double getResultado()
        {
            return this.resultado;
        }

        public void calcularmilhas()
        {
            this.resultado = this.milhas * 1.852;
        }

    }
}
