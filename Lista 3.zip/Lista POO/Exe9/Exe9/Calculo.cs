﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe9
{
    internal class Calculo
    {
        private int base1;
        private int altura;
        private int area;
        private string resultado;

        public Calculo(int base1, int altura, int area, string resultado)
        {
            this.base1 = base1;
            this.altura = altura;
            this.area = area;
            this.resultado = resultado;
        }

        public Calculo()
        {
            base1 = 0;
            altura = 0;
            area = 0;
            resultado = "";
        }

        public void setBase(int base1)
        {
            this.base1 = base1;
        }

        public void setAltura(int altura)
        {
            this.altura = altura;
        }

        public int getArea()
        {
            return this.area;
        }

        public string getResultado()
        {
            return this.resultado;
        }

        public void calcularArea()
        {
            this.area = this.base1 * this.altura;
        }

        public void verificarArea()
        {
            if (this.area > 100)
            {
                this.resultado = "grande";
            }
            else
            {
                this.resultado = "pequeno";
            }
        }
    }
}
