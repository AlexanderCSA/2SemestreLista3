﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            Calculo calculo = new Calculo();
            calculo.setLadoa(double.Parse(txt_ladoa.Text));
            calculo.setLadob(double.Parse(txt_ladob.Text));
            calculo.setLadoc(double.Parse(txt_ladoc.Text));
            calculo.classificar();
            lbl_resultado.Text = calculo.getClassificao();
        }
    }
}
