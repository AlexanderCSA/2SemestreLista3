﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe12
{
    internal class Calculo
    {
        private double ladoa;
        private double ladob;
        private double ladoc;
        private double resultado;
        private string classficacao;

        public Calculo(double ladoa, double ladob, double ladoc, double resultado, string classficacao)
        {
            this.ladoa = ladoa;
            this.ladob = ladob;
            this.ladoc = ladoc;
            this.resultado = resultado;
            this.classficacao = classficacao;
        }

        public Calculo()
        {
            this.ladoa = 0;
            this.ladob = 0;
            this.ladoc = 0;
            this.resultado = 0;
            this.classficacao = "";
        }

        public void setLadoa(double ladoa)
        {
            this.ladoa = Math.Pow(ladoa, 2);
        }

        public void setLadob(double ladob)
        {
            this.ladob = Math.Pow(ladob, 2);
        }

        public void setLadoc(double ladoc)
        {
            this.ladoc = Math.Pow(ladoc, 2);
        }
        
        public double getResultado() 
        {
            return resultado;
        }

        public string getClassificao()
        {
            return classficacao;
        }

        public void classificar()
        {
            if ((this.ladoa + this.ladob) == this.ladoc || (this.ladob + this.ladoc) == this.ladoa || (this.ladoa + this.ladoc) == this.ladob)
            {
                this.classficacao = "É um triangulo retangulo";
            }
            else
            {
                this.classficacao = "Não é um triangulo retangulo";
            }
        }
    }
}
