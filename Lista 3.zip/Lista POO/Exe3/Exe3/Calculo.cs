﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe3
{
    internal class Calculo
    {
        private double n1;
        private double lado;
        private double area;

        public Calculo(double n1, double resultado)
        {
            this.n1 = n1;
        }

        public Calculo()
        {
            this.n1 = 0;
        }

        public void setN1(double n1)
        {
            this.n1 = n1;
        }

        public double getN1()
        {
            return this.n1;
        }

        public double getArea()
        {
            return this.area;
        }
        public double getLado()
        {
            return this.lado;
        }
        public void calcularlado()
        {
            this.lado = this.n1 / Math.Sqrt(2);

        }

        public void calculararea()
        {
            this.area = Math.Pow(this.lado, 2);
        }
    }
}