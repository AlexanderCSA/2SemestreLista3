﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe10
{
    internal class Calculo
    {
        private double peso;
        private double altura;
        private double resultado;
        private string classificacao;

        public Calculo(double peso, double altura, double resultado, string classificacao)
        {
            this.peso = peso;
            this.altura = altura;
            this.resultado = resultado;
            this.classificacao = classificacao;
        }

        public Calculo()
        {
            this.peso = 0;
            this.altura = 0;
        }

        public void setPeso(double peso)
        {
            this.peso = peso;
        }

        public void setAltura(double altura)
        {
            this.altura = altura;
        }

        public void calcularimc()
        {
            this.resultado = this.peso / Math.Pow(this.altura, 2);
        }

        public string getClassificacao()
        {
            return this.classificacao;
        }

        public double getResultado()
        {
            return this.resultado;
        }
        public void classificar()
        {
            if (this.resultado < 20)
            {
                this.classificacao = "Abaixo de peso";
            }
            else if (this.resultado >= 20 && this.resultado < 25)
            {
                this.classificacao = "Peso ideal";
            }
            else
            {
                this.classificacao = "Acima do peso";
            }
        }
    }
}
