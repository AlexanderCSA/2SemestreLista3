﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe8
{
    internal class Calculo
    {
        private int valor1;
        private int valor2;
        private string maior;

        public Calculo(int valor1, int valor2, string maior)
        {
            this.valor1 = valor1;
            this.valor2 = valor2;
            this.maior = maior;
        }

        public Calculo()
        {
            this.valor1 = 0;
            this.valor2 = 0;
            this.maior = "";
        }

        public void setValor1(int valor1)
        {
            this.valor1 = valor1;
        }

        public void setValor2(int valor2)
        {
            this.valor2 = valor2;
        }

        public string getMaior()
        {
            return this.maior;
        }
        public void verificar()
        {
            if (this.valor1 > this.valor2)
            {
                this.maior = this.valor1.ToString();
            }
            else if(this.valor1 == this.valor2)
            {
                this.maior = "Os valores são identicos!";
            }
            else
            {
                this.maior = this.valor2.ToString();
            }
        }
    }
}
