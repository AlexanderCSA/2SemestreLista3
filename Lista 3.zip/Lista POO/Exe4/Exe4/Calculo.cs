﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe4
{
    internal class Calculo
    {
        private double bas3;
        private double altura;
        private double area;

        public Calculo(double bas3, double altura)
        {
            this.bas3 = bas3;
            this.altura = altura;
        }

        public Calculo() {
            this.bas3 = 0;
            this.altura = 0;
           
        }

        public void setBase(double bas3)
        {
            this.bas3 = bas3;
        }

        public void setAltura(double altura)
        {
            this.altura = altura;
        }

        public double getBase()
        {
            return this.bas3;
        }

        public double getArea()
        {
            return this.area;
        }       
      
        public void calculararea()
        {
            this.area = (this.bas3*this.altura)/2;
        }
    }
}
