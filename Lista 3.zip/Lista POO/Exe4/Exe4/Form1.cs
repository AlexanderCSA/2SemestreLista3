﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exe4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            Calculo calculo = new Calculo();
            calculo.setBase(Convert.ToDouble(txt_base.Text));
            calculo.setAltura(Convert.ToDouble(txt_altura.Text));
            calculo.calculararea();
            lbl_resultado.Text = "A área do triangulo é de: " + calculo.getArea()+" m²";
        }
    }
}
